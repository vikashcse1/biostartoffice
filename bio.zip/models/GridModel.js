const {Schema,model}=require('mongoose');

const GridModel = new Schema({
    start:{
        type:String,
        required:false,
    },
    limit:{
        type:String,
        required:false
    },
    sortCol:{
        type:String,
        required:false,
    },
    sortOrder:{
        type:Date,
        required:false,
    },
    searchVal:{
        type:String,
        required:false,
    }
});

module.exports=model("GridModel",GridModel)