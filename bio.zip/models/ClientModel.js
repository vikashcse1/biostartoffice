const { Schema, model } = require("mongoose");

const ClientModel = new Schema(
    {
        
        client_id: {
            type: String,
            required: false
          },
        aliasName: {
            type: String,
            required: false
          },
        bloodGroup: {
            type: String,
            required: false
          },
        dateofbirth: {
            type: String,
            required: false
          },
        user_id: {
            type: String,
            required: false
          },
        vendorId: {
            type: String,
            required: false
          },
        bloodGroupName: {
            type: String,
            required: false
          },
        bloodGroupSubType: {
            type: String,
            required: false
          },
        bloodGroupType: {
            type: String,
            required: false
          },
        relatedGroupClientID: {
            type: String,
            required: false
          },
        vendorNote: {
            type: String,
            required: false
          },
        last_access_date: {
            type: String,
            required: false
          }
    });

module.exports = model("ClientModel", ClientModel);