const { Schema, model } = require("mongoose");

const forgotpasswordresetlink = new Schema(
    {
[BsonElement("email_id")]
public string EmailId;
[BsonElement("_id")]
public string Id;
[BsonElement("datetime")]
public DateTime DateTime;
[BsonElement("first_name")]
public string FirstName;
[BsonElement("account_id")]
public string AccountId;
[BsonElement("user_id")]
public string UserId;
public string NewPassword;
});

module.exports = model("forgotpasswordresetlink", forgotpasswordresetlink);