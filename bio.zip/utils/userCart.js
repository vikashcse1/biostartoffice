const usercart=require("../models/usercart")


  const userCart= async (data,res)=>{
    all =  usercart.find({"email":data},(err, docs) => {
      if (!err) {
         usercart.findOneAndUpdate({
            email: "vikashdevil@gmail.com"
        }, {
    
            $push: {
                products: {
                    "Name:": req.body.products[0].Name,
                    "productPrice":req.body.products[0].productPrice,
                    "productId":req.body.products[0].productId
                },
    
            }
    
        },(err,docs)=>{
            if(err){
                console.log(err)
            }
            else{
                console.log(docs)
            }
        })
 
      }
      else { 
        let data = req.body
        const newusercart = new usercart({
            ...data,
        });
         newusercart.save();
        res.send(200)
      }
    });
    //console.log(all)
  };


  module.exports = {
    userCart
};