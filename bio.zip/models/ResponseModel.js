const {Schema,model}=require('mongoose');

const ResponseModel = new Schema({
    isSucess:{
        type:String,
        required:false,
    },
    message:{
        type:String,
        required:false
    },
    data:{
        type:String,
        required:false,
    }
});

module.exports=model("ResponseModel",ResponseModel)