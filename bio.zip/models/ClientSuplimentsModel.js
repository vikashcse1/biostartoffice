const { Schema, model } = require("mongoose");

const supplement = new Schema(
    {

        supplement_id: {
                type: String,
                required: true
              },
        CreationDate: {
            type: String,
            required: true
          },
        afterNoonVal1: {
            type: String,
            required: false
          },
        afterNoonVal2: {
            type: String,
            required: false
          },
        awakeningLung1: {
            type: String,
            required: true
          },
        awakeningLung2:{
            type: String,
            required: false
          },
        awakwaterchkbox:{
            type: String,
            required: false
          },
        bedTimeLiver1:{
            type: String,
            required: false
          },
        bedTimeLiver2:{
            type: String,
            required: false
          },
        bedTimePericardium1:{
            type: String,
            required: false
          },
        bedTimePericardium2:{
            type: String,
            required: false
          },
        bedtimesnackchkbox:{
            type: String,
            required: false
          },
        breakfastStomach1:{
            type: String,
            required: false
          },
        breakfastStomach2:{
            type: String,
            required: false
          },
        breakfastVal1:{
            type: String,
            required: false
          },
        breakfastVal2:{
            type: String,
            required: false
          },
        brkfastmealchkbox:{
            type: String,
            required: false
          },
        client_id:{
            type: String,
            required: false
          },
        date:{
            type: String,
            required: false
          },
        dinnerKidney1:{
            type: String,
            required: false
          },
        dinnerKidney2:{
            type: String,
            required: false
          },
        dinnerVal1:{
            type: String,
            required: false
          },
        dinnerVal2:{
            type: String,
            required: false
          },
        dinnermealchkbox:{
            type: String,
            required: false
          },

    });

module.exports = model("supplement", supplement);