const {Schema,model}=require('mongoose');

const soundMP3 = new Schema({
    ump3Id:{
        type:Number,
        required:false,
    },
    category:{
        type:String,
        required:false
    },
    license:{
        type:Date,
        required:false,
    },
    name:{
        type:String,
        required:false,
    },
    path:{
        type:String,
        required:false,
    }
});

module.exports=model("soundMP3",soundMP3)