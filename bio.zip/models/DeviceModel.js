const { Schema, model } = require("mongoose");

const devices = new Schema(
    {
        device_id: {
            type: String,
            required: false
          },
        ActivationKey: {
            type: String,
            required: false
          },
        Expires: {
            type: String,
            required: false
          },
        ExtdWExpires: {
            type: String,
            required: false
          },
        ExtdWYear: {
            type: String,
            required: false
          },
        HWSN: {
            type: String,
            required: false
          },
        InvInvoice: {
            type: String,
            required: false
          },
        InvLocation: {
            type: String,
            required: false
          },
        InvPurchaseDate: {
            type: String,
            required: false
          },
        Notes: {
            type: String,
            required: false
          },
        SWSN: {
            type: String,
            required: false
          },
        VendorID: {
            type: String,
            required: false
          },
        YearsWarrenty: {
            type: String,
            required: false
          },
        deviceCategory: {
            type: String,
            required: false
          },
        deviceCount: {
            type: String,
            required: false
          },
        rowIndex: {
            type: String,
            required: false
          },
        software: {
            type: String,
            required: false
          },
        canVendorEdit: {
            type: String,
            required: false
          },
        vendorName: {
            type: String,
            required: false
          },
        VendorPurchaseDate: {
            type: String,
            required: false
          },
        VendorInvoice: {
            type: String,
            required: false
          },
        InvReceivedDate: {
            type: String,
            required: false
          },
        type: {
            type: String,
            required: false
          },

    });

module.exports = model("devices", devices);