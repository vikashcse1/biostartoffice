const {Schema,model}=require('mongoose');

const LoginPrincipal = new Schema({
    
});

module.exports=model("LoginPrincipal",LoginPrincipal)