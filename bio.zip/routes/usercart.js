const router = require("express").Router();
const usercart = require("../models/usercart");
const user=require('../models/User')
const cors = require("cors");

//imorting function product
const {
    insert_product,
    get_products,
    delete_product
} = require("../utils/products");


// inserting a product

router.post("/", async (req, res, next) => {
    console.log(req.body)
    // userdId = req.body.used_id

    // await usercart.findByIdAndUpdate({
    //     used_id:"1234567"
    // }, {
    //     products:{
    //         $push: {
    //             "productName:": "james"
    //         },

    //     }

    // })

    let data = req.body
    const newusercart = new usercart({
        ...data,
    });
    await newusercart.save();
    res.send(200)
});


// inserting a product

router.post("/test", async (req, res, next) => {
    console.log(req.body)
    console.log(req.body.email)
    console.log(req.body.products)

    await usercart.findOneAndUpdate({
        email: req.body.email
    }, {


        $push: {
            products: {
                "Name:": req.body.products[0].Name,
                "productPrice": req.body.products[0].productPrice,
                "productId": req.body.products[0].productId
            },

        }

    })

    //await usercart.find(req.body.email, { $set: {products:{ productName: 'jason bourne' }}})

    // let data=req.body
    // const newusercart=new usercart({
    //     ...data,
    // });    
    // await newusercart.save();
    res.sendStatus(200)
});

router.post("/f", async (req, res) => {
    await user.findOne({ email: req.body.email }, (err, docs) => {
        if (!docs) {
            console.log(docs)
            console.log("not present")
            emailNotExist(req,res)
        }
        else {
            console.log("present")
            emailexist(req,res)
        }
    })
})

const emailexist=(req,res)=>{
    console.log("emailexist"+req.body.email)
    usercart.findOneAndUpdate({
        email: req.body.email
    }, {
        $push: {
            products: {
                "Name:": req.body.products[0].Name,
                "productPrice": req.body.products[0].productPrice,
                "productId": req.body.products[0].productId
            },
        }
    })
    res.sendStatus(200)
}
const emailNotExist=(req,res)=>{
    let data = req.body
    const newusercart = new usercart({
        ...data,
    });
    newusercart.save();
    res.sendStatus(200)
}


// Delet Product 
router.post("/delete_product", async (req, res, next) => {
    //console.log(req.body)
    await delete_product(req.body.id, res)
})

//Get all Product from db
router.get('/get_products', async (req, res, next) => {
    await get_products(res)
})


module.exports = router;



