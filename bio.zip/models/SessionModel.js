const {Schema,model}=require('mongoose');

const  SessionModel = new Schema({
    SuplimentData:{
        type:String,
        required:false,
    },
    AdvAnalysisData:{
        type:String,
        required:false,
    },
    PermittedClients:{
        type:String,
        required:false,
    },
    EnergyAnalysisData:{
        type:String,
        required:false,
    },
    ClientSessionType:{
        type:String,
        required:false,
    }
});

module.exports=model("SessionModel",SessionModel)