const {Schema,model}=require('mongoose');

const  vendors = new Schema({
    UserId:{
        type:Number,
        required:false,
    },
    VendorId:{
        type:Number,
        required:false,
    },
    IdnlsLicenseType:{
        type:Number,
        required:false,
    },
    PermittedClients:{
        type:String,
        required:false,
    },
    QuantumLicenseType:{
        type:String,
        required:false,
    },
    SoundBioStarLicenseType:{
        type:String,
        required:false,
    },
    Vendor:{
        type:String,
        required:false,
    },
    Vector:{
        type:String,
        required:false,
    },
    AdminNote:{
        type:String,
        required:false,
    },
    ExpiryDate:{
        type:Date,
        required:false
    }
});

module.exports=model("vendors",vendors)